/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       buzzer_task.c/h
  * @brief      buzzer warning task.��������������
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Nov-11-2019     RM              1. done
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "buzzer_task.h"
#include "main.h"
#include "cmsis_os.h"
#include "bsp_buzzer.h"
#include "detect_task.h"

static void buzzer_warn_error(uint8_t num);
static void buzzer_beep_pattern(void);

const error_t *error_list_test_local;



/**
  * @brief          test task
  * @param[in]      pvParameters: NULL
  * @retval         none
  */
/**
  * @brief          test����
  * @param[in]      pvParameters: NULL
  * @retval         none
  */
void buzzer_task(void const * argument)
{
    static uint8_t error, last_error;
    static uint8_t error_num;
    error_list_test_local = get_error_list_point();
	buzzer_beep_pattern();
    while(1)
    {
        error = 0;

        //find error
        //���ִ���
        for(error_num = 0; error_num < ERROR_LIST_LENGHT-1; error_num++)
        {
            if(error_list_test_local[error_num].error_exist)
            {
                error = 1;
                break;
            }
        }

        //no error, stop buzzer
        //û�д���, ֹͣ������
        if(error == 0 && last_error != 0)
        {
            buzzer_off();
        }
        //have error
        //�д���
        if(error)
        {
//            buzzer_warn_error(error_num+1);
        }

        last_error = error;
        osDelay(10);
    }
}


/**
  * @brief          make the buzzer sound
  * @param[in]      num: the number of beeps 
  * @retval         none
  */
/**
  * @brief          ʹ�÷�������
  * @param[in]      num:��������
  * @retval         none
  */
static void buzzer_warn_error(uint8_t num)
{
    static uint8_t show_num = 0;
    static uint8_t stop_num = 100;
    if(show_num == 0 && stop_num == 0)
    {
        show_num = num;
        stop_num = 100;
    }
    else if(show_num == 0)
    {
        stop_num--;
        buzzer_off();
    }
    else
    {
        static uint8_t tick = 0;
        tick++;
        if(tick < 50)
        {
            buzzer_off();
        }
        else if(tick < 100)
        {
            buzzer_on(1, 30000);
        }
        else
        {
            tick = 0;
            show_num--;
        }
    }
}




/**
  * @brief          Play a predefined beep pattern for notification
  * @retval         none
  */
static void buzzer_beep_pattern(void)
{
    const uint16_t tones[][2] = {
        {3, 400},
        {2, 300},
        {1, 300}
    };
    
    for (uint8_t i = 0; i < sizeof(tones) / sizeof(tones[0]); i++)
    {
        if (tones[i][0] > 0)
        {
            buzzer_on(tones[i][0], 3000);
        }
        else
        {
            buzzer_off();
        }
        osDelay(tones[i][1]);
    }
    buzzer_off();
}

