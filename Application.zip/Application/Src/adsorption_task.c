/**
  ******************************************************************************
  * @file       adsorption_task.c/h
  * @brief      �����߳�
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ******************************************************************************
  */
  
#include "adsorption_task.h"
#include "cmsis_os.h"
#include "remote_receive.h"
#include "arm_math.h"
#include "user_lib.h"


#include <string.h>
#include <math.h>

/*---------------------------- ��̬���� ----------------------------*/
// ѹ��������ԭʼ���ݶ�ȡ
static HAL_StatusTypeDef ReadPressureRaw(I2C_HandleTypeDef* hi2c, uint8_t* buf) 
{
    const uint8_t cmd = 0x06;  // ���ݼĴ�����ַ
    return HAL_I2C_Mem_Read(hi2c, (0x6D<<1)|0x01, cmd, 
                          I2C_MEMADD_SIZE_8BIT, buf, 3, 50);
}

// ѹ��ֵת����������У�飩
static float ConvertPressure(uint8_t* raw_data)
{
    // ������Ч��У��
    if((raw_data[0] == 0xFF) && (raw_data[1] == 0xFF) && (raw_data[2] == 0xFF)) {
        return NAN;
    }
    
    // ԭʼ���ݴ���
    int32_t raw = (raw_data[0] << 16) | (raw_data[1] << 8) | raw_data[2];
    
    // ��ѹת���߼�
    if((raw & 0x00800000) == 0) {
        return 0.0f;  // ��ѹ��Ϊ0
    }
    return (16777216 - raw) / 1000.0f * -1.0f;
}

/*---------------------------- ���нӿ�ʵ�� ----------------------------*/
void Adsorption_Init(AdsorptionSystem* sys, 
                    I2C_HandleTypeDef* press_i2c,
                    TIM_HandleTypeDef* fan_tim,
                    float init_target)
{
    memset(sys, 0, sizeof(*sys));
    
    // Ӳ���ӿڰ�
    sys->press_i2c = press_i2c;
    sys->fan_tim = fan_tim;
    
    // PID������ʼ��
    sys->kp = 2.5f;
    sys->ki = 0.1f;
    sys->kd = 0.05f;
    sys->target_kPa = init_target;
    
    // ����PWM
    HAL_TIM_PWM_Start(sys->fan_tim, TIM_CHANNEL_1);
}

void Adsorption_TaskEntry(void const* arg)
{
    AdsorptionSystem* sys = (AdsorptionSystem*)arg;
    uint8_t press_raw[3];
    
    for(;;) {
        // 1. ��ȡѹ��������
        if(ReadPressureRaw(sys->press_i2c, press_raw) == HAL_OK) {
            float new_press = ConvertPressure(press_raw);
            
            if(!isnan(new_press)) {
                // һ�׵�ͨ�˲�
                sys->current_kPa = 0.2f * new_press + 0.8f * sys->current_kPa;
            }
        }
        
        // 2. ��ȫ���
        if(sys->current_kPa > SAFETY_THRESHOLD) {
            if(++sys->safety_counter > PRESSURE_TIMEOUT) {
                Adsorption_EmergencyHandler(sys);
            }
        } else {
            sys->safety_counter = 0;
        }
        
        // 3. PID����
        if(sys->is_active) {
            float error = sys->target_kPa - sys->current_kPa;
            
            // ������������ͣ�
            sys->integral += sys->ki * error * (CONTROL_PERIOD_MS/1000.0f);
            sys->integral = fmaxf(0, fminf(100.0f, sys->integral));
            
            // ΢�����PV΢�֣�
            static float last_pv = 0;
            float derivative = (sys->current_kPa - last_pv) / 
                              (CONTROL_PERIOD_MS/1000.0f);
            last_pv = sys->current_kPa;
            
            // �������
            float output = sys->kp * error + 
                          sys->integral - 
                          sys->kd * derivative;
            output = fmaxf(0, fminf(100.0f, output));
            
            // 4. ���÷����ʹ��ԭBSP�ӿڣ�
            bsp_fan_set_speed(FAN_MAIN_INDEX, (uint16_t)output); 
        }
        
        osDelay(CONTROL_PERIOD_MS);  // FreeRTOS��ʱ
    }
}

void Adsorption_EmergencyHandler(AdsorptionSystem* sys)
{
    // ����ԭʼBSP�ӿ�
    bsp_fan_stop_all();
    
    // ϵͳ״̬����
    sys->is_active = 0;
    sys->safety_counter = 0;
    sys->integral = 0.0f;
    
    // Ӳ������
    __HAL_TIM_SET_COMPARE(sys->fan_tim, TIM_CHANNEL_1, 0);
}