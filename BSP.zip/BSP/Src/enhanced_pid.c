#include "enhanced_pid.h"
#include <math.h>

void PID_Init(EnhancedPID* pid, float kp, float ki, float kd, float kff,
             float min_out, float max_out) {
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->kff = kff;
    pid->integral = 0;
    pid->last_error = 0;
    pid->max_output = max_out;
    pid->min_output = min_out;
}

float PID_Calculate(EnhancedPID* pid, float setpoint, float pv, float dt) {
    float error = setpoint - pv;
    
    // ������������ͣ�
    pid->integral += pid->ki * error * dt;
    pid->integral = fmaxf(pid->min_output, fminf(pid->max_output, pid->integral));
    
    // ΢���΢�����У�
    float derivative = (pv - pid->last_error) / dt;
    
    // ǰ����
    float feedforward = pid->kff * setpoint;
    
    // ���������
    float output = pid->kp * error + 
                  pid->integral - 
                  pid->kd * derivative + 
                  feedforward;
    
    // ����޷�
    output = fmaxf(pid->min_output, fminf(pid->max_output, output));
    
    pid->last_error = pv;
    return output;
}