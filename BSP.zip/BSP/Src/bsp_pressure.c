#include "bsp_pressure.h"
#include <string.h>

#define FILTER_ALPHA   0.2f  // һ�׵�ͨ�˲�ϵ��

void BSP_Pressure_Init(BSP_PressureSensor* sensor, I2C_HandleTypeDef* hi2c) {
    memset(sensor, 0, sizeof(*sensor));
    sensor->hi2c = hi2c;
    sensor->is_initialized = 1;
    
    // ���ô�����Ϊ125ms����ģʽ
    uint8_t cmd = 0x2B;
    HAL_I2C_Mem_Write(sensor->hi2c, (PRESS_W_ADDRESS<<1), 0x30,
                     I2C_MEMADD_SIZE_8BIT, &cmd, 1, PRESS_I2C_TIMEOUT);
}

HAL_StatusTypeDef BSP_Pressure_Update(BSP_PressureSensor* sensor) {
    if (!sensor->is_initialized) return HAL_ERROR;
    
    uint8_t raw_data[3];
    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(sensor->hi2c, (PRESS_W_ADDRESS<<1),
                        PRESS_DATA_REG, I2C_MEMADD_SIZE_8BIT, raw_data, 3, PRESS_I2C_TIMEOUT);
    
    if (status == HAL_OK) {
        // ԭʼ���ݴ���
        int32_t raw = (raw_data[0] << 16) | (raw_data[1] << 8) | raw_data[2];
        float current = (raw & 0x00800000) ? 
                       ((16777216 - raw) / 1000.0f) * -1.0f : 0.0f;
        
        // ��ͨ�˲�
        sensor->filtered_kPa = FILTER_ALPHA * current + 
                              (1-FILTER_ALPHA) * sensor->filtered_kPa;
    }
    return status;
}

float BSP_Pressure_GetkPa(BSP_PressureSensor* sensor) {
    return sensor->filtered_kPa;
}