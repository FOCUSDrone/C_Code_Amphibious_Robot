
#include <stdint.h>

typedef struct {
    float kp, ki, kd, kff;
    float integral;
    float last_error;
    float max_output;
    float min_output;
} EnhancedPID;

// ��ʼ��PID������
void PID_Init(EnhancedPID* pid, float kp, float ki, float kd, float kff,
             float min_out, float max_out);

// ִ��PID����
float PID_Calculate(EnhancedPID* pid, float setpoint, float pv, float dt);